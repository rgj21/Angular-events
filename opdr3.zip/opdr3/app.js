var app = angular.module('mijnEventApp', []);

app.controller('mijnEventController', function($scope) {
  $scope.dbcount = 0;
  $scope.MouseOverCount = 0;
  $scope.MouseLeaveCount = 0;
  $scope.singleKlik = 0;
  $scope.totaal = 0;


  $scope.trackMouse = function(hetEvent) {
    $scope.x = hetEvent.clientX;
    $scope.y = hetEvent.clientY;


    $scope.dubbelKlik = function(event) {
      $scope.dbcount += 1;
      $scope.totaal += 1;
    }
    $scope.onMouseEnter = function(event) {
      $scope.MouseOverCount += 1;
      $scope.totaal += 1;
    }
    $scope.onMouseLeave = function(event) {
      $scope.MouseLeaveCount += 1;
      $scope.totaal += 1;
    }
    $scope.klick = function(event) {
      $scope.singleKlik += 1 ;
      $scope.totaal += 1;
    }


  }

});
